const CONSTANT = {
    GRID_SIZE: 9,
    UNASSIGNED: 0,
    BOX_SIZE: 3,
    NUMBERS: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    LEVEL_NAME: [
        'Easy',
        'Medium',
        'Hard',
    ],
    LEVEL: [29, 38, 47]
}